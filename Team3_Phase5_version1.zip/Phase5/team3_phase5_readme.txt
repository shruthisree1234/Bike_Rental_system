CSE 5330 DATABASE SYSTEMS
PHASE 5
BIKE RENTAL SYSTEM - FRONT END DEVELOPMENT

TEAM 3
DUY NGUYEN (1001215102)
SHRUTHI SREE THIRUNAVUKKARASU (1001933428)
YASHASWINI ASHOK (1002074339)


Instructions

1. Use XXAMP to create a localhost server and add the downloaded project files in /Applications/XAMPP/xamppfiles/htdocs.

2. Sign in to Open pulse Secure VPN and connect with the oracle database.

3. Run "projectDBcreate.sql" to create tables and then run "projectDBinsert.sql" to populate the created tables.

4. Open a Web browser and go to "localhost" to open the app.